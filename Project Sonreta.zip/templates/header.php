<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Sonreta</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>