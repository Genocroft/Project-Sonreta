<?php
require_once '../templates/header.php';
?>

<div class="containerUpperBarRight">
    <div class="logo">Logo</div>
    <div class="title">Sonreta</div>
    <div class="help">Help</div>
        <div class="containerUpperBarLeft"></div>
         <div class="servers">Servers</div>
            <div class="account">Account</div>
            <div class="username">Username</div>
         <div class="icon">Icon</div>
    </div>
</div>

<?php
//require_once '../templates/footer.php';
?>